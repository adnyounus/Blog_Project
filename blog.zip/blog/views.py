from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Post
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required


def user_logout(request):
	logout(request)
	return redirect('blog-home')

def user_login(request):
	if (request.user.is_authenticated):
		return redirect('blog-home')
	else:		
		return render(request, 'blog/login.html')

def user_login_verify(request):
	user_ = request.POST.get('username', '')
	pass_ = request.POST.get('password', '')

	user = authenticate(username=user_, password=pass_)

	if user is not None:
		login(request, user)
		return redirect('blog-home')
	else:
		messages.error(request, 'Incorrect Username/Password')
		return redirect('blog-login')


def home(request):
	context = {
		'posts' : Post.objects.all()
	}
	return render(request, 'blog/home.html', context)
	# return HttpResponse('<h1>Hello, welcome to our blog</h1>')

@login_required
def about(request):
	return render(request, 'blog/about.html', {'title' : 'About Page'})
	# return HttpResponse('<h1>About Page</h1><h2>A CSE-465 Project</h2>')

# Create your views here.
