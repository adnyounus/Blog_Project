from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='blog-home'),
    path('aboutus/', views.about, name='blog-about'),
    path('login/', views.user_login, name='blog-login'),
    path('login-verify/', views.user_login_verify, name='blog-login-verify'),
    path('logout/', views.user_logout, name='blog-logout'),
]
